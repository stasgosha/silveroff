<?php $page_title = 'Страница товара'; ?>
<?php include('header.php'); ?>
	<div class="page-content">
		<section class="breadcrumbs-section">
			<div class="container">
				<ol class="breadcrumbs" itemscope itemtype="http://schema.org/BreadcrumbList">
					<li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem">
						<a itemprop="item" href="catalog.php">
							<span itemprop="name">Каталог</span>
						</a>
						<meta itemprop="position" content="1" />
					</li>
					<li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem">
						<a itemprop="item" href="catalog.php">
							<span itemprop="name">Серебряные цепочки</span>
						</a>
						<meta itemprop="position" content="2" />
					</li>
					<li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem">
						<a itemprop="item" href="catalog.php">
							<span itemprop="name"><?= $page_title ?></span>
						</a>
						<meta itemprop="position" content="3" />
					</li>
				</ol>
			</div>
		</section>
		<div class="product-page-section">
			<div class="container">
				<div class="row">
					<div class="col-xl-9">
						<div class="product-photos-component">
							<div class="product-photos-previews">
								<div class="previews-slider">
									<div class="slide">
										<div class="preview-image">
											<img src="img/product-page/ring-preview.jpg" alt="">
										</div>
									</div>
									<div class="slide">
										<div class="preview-image">
											<img src="img/product-page/ring-preview.jpg" alt="">
										</div>
									</div>
									<div class="slide">
										<div class="preview-image">
											<img src="img/product-page/ring-preview.jpg" alt="">
										</div>
									</div>
									<div class="slide">
										<div class="preview-image">
											<img src="img/product-page/ring-preview.jpg" alt="">
										</div>
									</div>
									<div class="slide">
										<div class="preview-image">
											<img src="img/product-page/ring-preview.jpg" alt="">
										</div>
									</div>
								</div>
							</div>
							<div class="product-photos-big-image">
								<div class="product-labels">
									<div class="item green">Новинка</div>
									<div class="item red">-50%</div>
								</div>
								<div class="big-image-slider">
									<div class="slide">
										<img src="img/product-page/ring-large.jpg" alt="">
									</div>
									<div class="slide">
										<img src="img/product-page/ring-large.jpg" alt="">
									</div>
									<div class="slide">
										<img src="img/product-page/ring-large.jpg" alt="">
									</div>
									<div class="slide">
										<img src="img/product-page/ring-large.jpg" alt="">
									</div>
									<div class="slide">
										<img src="img/product-page/ring-large.jpg" alt="">
									</div>
								</div>
								<div class="share-link">
									<i class="icon-plus"></i>
									<span>Поделиться</span>
								</div>
							</div>
						</div>
					</div>
					<div class="col-xl-5">
						<div class="product-about-component">
							<div class="short-info">
								<div class="item">
									<p class="slf-body-1 small margin-no">Бренд: <strong>Casual</strong></p>
									<p class="slf-body-1 small margin-no">Производство: <strong>Россия</strong></p>
								</div>
								<div class="item">
									<p class="slf-body-1 small margin-no color-text-lightgray">Артикул: <strong>31101122</strong></p>
								</div>
							</div>
							<h1 class="product-caption">Толстая серебряная цепь мужская, плетение Бисмарк, ручной вязке, 250 гр. с чернением, ширина 1,6 см</h1>
							<p class="product-description">Браслет из серебра шириной 2 см создан для мужчин, которые привыкли приковывать к себе внимание и получают от этого немалое удовольствие. Стильное украшение обработано способом родирования, благодаря чему приобретает сияющий блеск.</p>
							<div class="divider"></div>
							<div class="product-size-select">
								<p class="pss-caption">
									<i class="icon-ruler"></i>
									<span>Размеры в наличии</span>
								</p>
								<ul class="sizes-list">
									<li>
										<div class="selectable big">
											<input type="checkbox" id="product-size-16-5" checked>
											<label for="product-size-16-5">16.5</label>
										</div>
									</li>
									<li>
										<div class="selectable big">
											<input type="checkbox" id="product-size-17">
											<label for="product-size-17">17</label>
										</div>
									</li>
									<li>
										<div class="selectable big">
											<input type="checkbox" id="product-size-18-5">
											<label for="product-size-18-5">18.5</label>
										</div>
									</li>
									<li>
										<div class="selectable big wide">
											<input type="checkbox" id="product-size-none">
											<label for="product-size-none">Не знаю размер</label>
										</div>
									</li>
								</ul>
								<div class="pss-links">
									<div class="item">
										<a href="#">Не нашли нужный размер?</a>
									</div>
									<div class="item">
										<a href="#">Как подобрать размер</a>
									</div>
								</div>
							</div>
							<div class="divider"></div>
							<div class="product-price">
								<div class="current-price">25 505 р.</div>
								<div class="old-price">
									<div class="val">37 505 р.</div>
									<div class="economy">Вы экономите: 12000 р.</div>
								</div>
							</div>
							<div class="product-buttons">
								<div class="item">
									<button class="btn btn-gray fullwidth">Купить</button>
								</div>
								<div class="item">
									<button class="btn fullwidth">Купить в 1 клик</button>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
<?php include('footer.php'); ?>